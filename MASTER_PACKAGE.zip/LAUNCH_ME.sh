#!/bin/bash
# ============================================================
#  DEALWALAINDIA - MASTER LAUNCHER (Mac/Linux)
#  One-click automation for RedBus booking
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

show_menu() {
    clear
    cat << 'EOF'

╔══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║        🚀 DEALWALAINDIA BUS BOOKING AUTOMATION                      ║
║                                                                       ║
║        Passenger: Lalit Chordiya                                      ║
║        UPI: lalitkchordiya-1@oksbi                                   ║
║                                                                       ║
║        ONE-CLICK LAUNCHER                                             ║
║        Just pick a route and watch Chrome do the work!                ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝

============================================================
 SELECT ROUTE:
============================================================

    [1] Pune → Nashik
        (Tomorrow, shows ALL buses - cheapest first)

    [2] Pune → Indore
        (3 days ahead, AC + Sleeper, cheapest first)

    [3] Pune → Bangalore
        (3 days ahead, AC + Sleeper, cheapest first)

    [4] Run Environment Test (check setup)

    [5] Exit

============================================================

EOF
    read -p "  Enter your choice (1-5) and press Enter: " choice
}

check_python() {
    echo ""
    echo "  [1/3] Checking Python..."
    if command -v python3 &> /dev/null; then
        PYTHON=python3
    elif command -v python &> /dev/null; then
        PYTHON=python
    else
        echo ""
        echo "  ERROR: Python not found!"
        echo "  Please install Python 3.7+"
        echo "  Mac: brew install python3"
        echo "  Ubuntu/Debian: sudo apt install python3 python3-pip"
        echo ""
        read -p "  Press Enter to continue..."
        return 1
    fi
    $PYTHON --version
    echo "  ✅ Python OK"
    return 0
}

check_deps() {
    echo ""
    echo "  [2/3] Checking/Installing dependencies..."
    pip3 install --upgrade pip 2>/dev/null || true
    pip3 install selenium webdriver-manager --upgrade 2>/dev/null || {
        $PYTHON -m pip install selenium webdriver-manager --upgrade 2>/dev/null || {
            echo "  ⚠️  Could not auto-install. Please run:"
            echo "     pip install selenium webdriver-manager"
        }
    }
    echo "  ✅ Dependencies ready"
    echo ""
}

run_route() {
    local route_name="$1"
    local script_name="$2"
    local display_name="$3"

    clear
    echo ""
    echo "  ============================================================"
    echo "   $display_name"
    echo "  ============================================================"
    echo ""

    check_python || return
    check_deps

    echo "  [3/3] Starting automation..."
    echo ""
    echo "  ============================================================"
    echo "   ROUTE: $route_name"
    echo "   Chrome will OPEN VISIBLY in 5 seconds."
    echo "   DO NOT CLOSE THE BROWSER!"
    echo "  ============================================================"
    echo ""

    sleep 5
    cd "$SCRIPT_DIR"
    $PYTHON "scripts/$script_name"

    echo ""
    echo "  ============================================================"
    echo "   AUTOMATION COMPLETED - Check browser for payment"
    echo "  ============================================================"
    echo ""
    read -p "  Press Enter to return to menu..."
}

run_test() {
    clear
    echo ""
    echo "  ============================================================"
    echo "   RUNNING ENVIRONMENT TEST..."
    echo "  ============================================================"
    echo ""

    check_python || { read -p "Press Enter..."; return; }

    cd "$SCRIPT_DIR"
    $PYTHON test_setup.py

    echo ""
    read -p "  Press Enter to return to menu..."
}

while true; do
    show_menu

    case "$choice" in
        1) run_route "Pune → Nashik" "book_pune_nashik.py" "PUNE → NASHIK - CHEAPEST BUS" ;;
        2) run_route "Pune → Indore" "book_pune_indore.py" "PUNE → INDORE - AC SLEEPER" ;;
        3) run_route "Pune → Bangalore" "book_pune_bangalore.py" "PUNE → BANGALORE - AC SLEEPER" ;;
        4) run_test ;;
        5)
            clear
            echo ""
            echo "  Thank you for using DealwalaIndia Automation!"
            echo ""
            echo "  Happy journey! 🚍"
            echo ""
            exit 0
            ;;
        *)
            echo ""
            echo "  ❌ Invalid choice! Please enter 1, 2, 3, 4, or 5."
            echo ""
            read -p "  Press Enter to continue..."
            ;;
    esac
done
