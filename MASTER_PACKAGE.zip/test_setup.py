#!/usr/bin/env python3
"""
TEST SETUP - Verify your environment for DealwalaIndia automation.
Run this first to check if everything is ready!
"""

import sys
import subprocess
import shutil
import json
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "passenger_config.json")
RESULTS = {"passed": 0, "failed": 0, "warnings": 0}

def check(name, condition, fail_hint=""):
    if condition:
        print(f"   ✅ {name}")
        RESULTS["passed"] += 1
    else:
        if fail_hint:
            print(f"   ❌ {name}")
            print(f"      ⚠️  {fail_hint}")
        else:
            print(f"   ⚠️  {name} (warning)")
            RESULTS["warnings"] += 1
        RESULTS["failed"] += 1

print("""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║     🔍 DEALWALAINDIA - ENVIRONMENT TEST                              ║
║                                                                       ║
║     This will check if your system is ready to run the               ║
║     bus booking automation scripts.                                  ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
""")

print("=" * 70)
print("  [1/6] Python Version")
print("=" * 70)
check("Python 3.7+", sys.version_info >= (3, 7),
      f"Found Python {sys.version_info.major}.{sys.version_info.minor}. Please install Python 3.7+")
print(f"   Version: Python {sys.version.split()[0]}")

print("\n" + "=" * 70)
print("  [2/6] Selenium Library")
print("=" * 70)
try:
    import selenium
    print(f"   Version: {selenium.__version__}")
    check("Selenium installed", True)
except ImportError:
    check("Selenium installed", False, "Run: pip install selenium")

print("\n" + "=" * 70)
print("  [3/6] WebDriver Manager")
print("=" * 70)
try:
    import webdriver_manager
    print(f"   Version: {webdriver_manager.__version__}")
    check("webdriver-manager installed", True)
except ImportError:
    check("webdriver-manager installed", False, "Run: pip install webdriver-manager")

print("\n" + "=" * 70)
print("  [4/6] Chrome Browser")
print("=" * 70)
chrome_paths = [
    "google-chrome", "google-chrome-stable",
    "chromium", "chromium-browser",
    "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
]
chrome_found = False
for path in chrome_paths:
    if shutil.which(path):
        print(f"   Found: {path}")
        chrome_found = True
        break
check("Chrome browser found", chrome_found,
      "Install Google Chrome: https://www.google.com/chrome/")

if chrome_found:
    try:
        result = subprocess.run(
            [shutil.which(chrome_paths[0]), "--version"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            print(f"   Version: {result.stdout.strip()}")
    except:
        pass

print("\n" + "=" * 70)
print("  [5/6] Import All Modules")
print("=" * 70)
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import Select
    check("All selenium modules import successfully", True)
except Exception as e:
    check("All selenium modules import successfully", False, str(e))

print("\n" + "=" * 70)
print("  [6/6] Configuration File")
print("=" * 70)
if os.path.exists(CONFIG_PATH):
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        p = config.get("passenger", {})
        name_ok = bool(p.get("name"))
        routes_ok = bool(config.get("routes"))
        check(f"Config found: {p.get('name', 'UNKNOWN')}", name_ok,
              "Missing passenger name in config")
        routes = config.get("routes", {})
        for key, r in routes.items():
            check(f"Route: {r.get('description', key)}", True)
    except Exception as e:
        check("Configuration file valid JSON", False, str(e))
else:
    check("Configuration file exists", False, "passenger_config.json not found!")

print("\n" + "=" * 70)
print("  TEST SUMMARY")
print("=" * 70)
print(f"""
   ✅ Passed: {RESULTS['passed']}
   ⚠️  Warnings: {RESULTS['warnings']}
   ❌ Failed: {RESULTS['failed']}
""")

if RESULTS["failed"] == 0:
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                    ✅ ALL CHECKS PASSED!                             ║
║                                                                       ║
║     Your system is ready! Run the launcher to start:                   ║
║                                                                       ║
║     Windows: Double-click LAUNCH_ME.bat                               ║
║     Mac/Linux:  ./LAUNCH_ME.sh                                        ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
""")
else:
    print("""
╔══════════════════════════════════════════════════════════════════════╗
║                    ⚠️  SOME CHECKS FAILED                            ║
║                                                                       ║
║     Please fix the issues above before running the automation.        ║
║     Common fixes:                                                     ║
║                                                                       ║
║     1. pip install selenium webdriver-manager                        ║
║     2. Install Google Chrome from https://www.google.com/chrome/      ║
║     3. Make sure passenger_config.json is in the same folder          ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
""")

print("=" * 70)
print("  Need help? Check README.md for detailed instructions")
print("=" * 70)
