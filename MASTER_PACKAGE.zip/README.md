# 🚍 DealwalaIndia - Bus Booking Automation Package

**Complete one-click automation for booking buses on RedBus for Lalit Chordiya.**

Three routes: Pune→Nashik, Pune→Indore, Pune→Bangalore.

---

## 📦 Package Contents

| File / Folder | Purpose |
|---|---|
| `LAUNCH_ME.bat` | **Windows master launcher** — double-click to start |
| `LAUNCH_ME.sh` | **Mac/Linux master launcher** — `./LAUNCH_ME.sh` to start |
| `passenger_config.json` | Your details — Name, Email, Phone, UPI |
| `requirements.txt` | Python dependencies |
| `test_setup.py` | Environment test script |
| `scripts/book_pune_nashik.py` | Pune → Nashik automation |
| `scripts/book_pune_indore.py` | Pune → Indore automation |
| `scripts/book_pune_bangalore.py` | Pune → Bangalore automation |

---

## 🚀 Quick Start (30 seconds)

### Windows
1. **Double-click** `LAUNCH_ME.bat`
2. Choose a route (1, 2, or 3)
3. Watch Chrome open and automate everything!
4. Complete UPI payment in the browser

### Mac / Linux
```bash
chmod +x LAUNCH_ME.sh
./LAUNCH_ME.sh
```
Choose a route and watch the magic happen!

---

## 📋 Requirements

| Requirement | Check |
|---|---|
| **Python 3.7+** | `python --version` or `python3 --version` |
| **Google Chrome** | Latest version installed |
| **Internet connection** | Stable connection required |

Dependencies (auto-installed by launcher):
- `selenium` — Browser automation
- `webdriver-manager` — Auto-manages ChromeDriver

---

## 🎬 What Each Route Does

### 1️⃣ Pune → Nashik (Tomorrow Night)
- Opens RedBus for tomorrow
- Shows ALL buses (no AC filter — finds the truly cheapest)
- Sorts by Price (Low to High)
- Clicks "View Seats" on cheapest bus
- Waits 30s for you to select a seat
- Fills your details automatically
- Proceeds to payment page
- **You pay via UPI**

### 2️⃣ Pune → Indore (3 days ahead)
- Opens RedBus for 3 days from now
- Filters: AC + Sleeper
- Sorts by Price (Low to High)
- Clicks "View Seats" on cheapest bus
- Waits 20s for you to select a seat
- Fills your details automatically
- Proceeds to payment page
- **You pay via UPI**

### 3️⃣ Pune → Bangalore (3 days ahead)
- Opens RedBus for 3 days from now
- Filters: AC + Sleeper
- Sorts by Price (Low to High)
- Clicks "View Seats" on cheapest bus
- Waits 20s for you to select a seat
- Fills your details automatically
- Proceeds to payment page
- **You pay via UPI**

---

## 👤 Your Details (Pre-configured)

All details are in `passenger_config.json`:

```json
{
  "passenger": {
    "name": "Lalit Chordiya",
    "age": "44",
    "gender": "Male",
    "email": "lalitkchordiya@gmail.com",
    "phone": "9730472789",
    "upi": "lalitkchordiya-1@oksbi"
  }
}
```

To change: edit the JSON file with any text editor.

---

## 🧪 Test Your Setup First

Run the environment test to make sure everything is ready:

```bash
# Windows: From the menu, choose option 4
# Or directly:
python test_setup.py

# Mac/Linux:
python3 test_setup.py
```

This checks:
- ✅ Python version
- ✅ Selenium installed
- ✅ WebDriver Manager installed
- ✅ Chrome browser found
- ✅ All modules import correctly
- ✅ Configuration file valid

---

## 🔧 Troubleshooting

| Problem | Solution |
|---|---|
| `Python not found` | Install Python 3.7+ from python.org |
| `ModuleNotFoundError: selenium` | Run: `pip install selenium webdriver-manager` |
| `Chrome not found` | Install Google Chrome from google.com/chrome |
| `ChromeDriver` error | The webdriver-manager handles this automatically |
| Automation stops midway | Browser stays open — continue manually |
| Wrong passenger details | Edit `passenger_config.json` and re-run |

---

## 💡 Tips

- **Run `test_setup.py` first** to verify your environment
- **First run takes longer** as ChromeDriver downloads
- **Watch the browser** — you can intervene at any step
- **Screenshots are saved** to the current folder as `.png` files
- **Edit `default_days_ahead`** in `passenger_config.json` to change travel date
- **Browser stays open** after automation — close it manually when done

---

## 💰 Payment

The automation takes you to the payment page. You complete:
1. Select **UPI** as payment method
2. Enter UPI ID: `lalitkchordiya-1@oksbi`
3. Click **Pay Now**
4. Approve in Google Pay / PhonePe / Paytm
5. E-ticket sent via SMS & Email

---

## 🗺️ Directory Structure

```
MASTER_PACKAGE/
├── LAUNCH_ME.bat             # Windows launcher (double-click)
├── LAUNCH_ME.sh              # Mac/Linux launcher
├── passenger_config.json     # Your passenger details
├── requirements.txt          # Dependencies
├── test_setup.py             # Environment test
├── README.md                 # This file
└── scripts/
    ├── book_pune_nashik.py   # Pune → Nashik
    ├── book_pune_indore.py   # Pune → Indore
    └── book_pune_bangalore.py # Pune → Bangalore
```

---

## 📝 License

For personal use. This automation is for educational purposes.
You are responsible for verifying all booking details before payment.

---

*Last updated: May 2026 — Happy journey Lalit! 🚍*
