#!/usr/bin/env python3
"""
DEALWALAINDIA - RedBus Automation: Pune → Indore
Opens Chrome VISIBLY, finds cheapest AC Sleeper bus, fills details, takes you to payment.

Usage: python scripts/book_pune_indore.py
"""

import sys
import os
import json
import time
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(os.path.dirname(SCRIPT_DIR), "passenger_config.json")

with open(CONFIG_PATH) as f:
    CONFIG = json.load(f)

PASSENGER = CONFIG["passenger"]
ROUTE_INFO = CONFIG["routes"]["pune_indore"]

today = datetime.now()
target_date = today + timedelta(days=ROUTE_INFO["default_days_ahead"])
DATE_STR = target_date.strftime("%d-%b-%Y")

print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║     🚀 DEALWALAINDIA - PUNE → INDORE AUTOMATION                       ║
║                                                                       ║
║     Route: Pune → Indore                                              ║
║     Date:  {DATE_STR}                                                    ║
║                                                                       ║
║     Chrome will OPEN VISIBLY — you watch everything!                  ║
║                                                                       ║
║     Passenger: {PASSENGER['name']:<54} ║
║     Email:     {PASSENGER['email']:<54} ║
║     Phone:     {PASSENGER['phone']:<54} ║
║     UPI:       {PASSENGER['upi']:<54} ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
""")

try:
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import Select
except ImportError as e:
    print(f"\n❌ Error: {e}")
    print("\n💡 Run: pip install selenium webdriver-manager")
    sys.exit(1)

try:
    from webdriver_manager.chrome import ChromeDriverManager
    WM_AVAILABLE = True
except ImportError:
    WM_AVAILABLE = False

url = f"https://www.redbus.in/bus-tickets/{ROUTE_INFO['redbus_slug']}?date={DATE_STR}"
print(f"\n🔗 URL: {url}")

print("\n" + "=" * 70)
print("⚠️  Chrome will open in 5 seconds. DO NOT CLOSE it!")
print("=" * 70)
for i in range(5, 0, -1):
    print(f"{i}...")
    time.sleep(1)

options = Options()
options.add_experimental_option("detach", True)
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

driver = None
try:
    if WM_AVAILABLE:
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=options
        )
    else:
        driver = webdriver.Chrome(options=options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    print("✅ Chrome launched successfully!")
except Exception as e:
    print(f"\n❌ Chrome failed to launch: {e}")
    print("\n💡 Make sure Google Chrome is installed: https://www.google.com/chrome/")
    sys.exit(1)

def screenshot(name):
    try:
        ts = datetime.now().strftime("%H%M%S")
        fname = f"pune_indore_{name}_{ts}.png"
        driver.save_screenshot(fname)
        print(f"📸 {fname}")
    except:
        pass

def fill(selectors, value, label):
    for sel in selectors.split(", "):
        try:
            els = driver.find_elements(By.CSS_SELECTOR, sel.strip())
            for el in els:
                if el.is_displayed():
                    el.clear()
                    el.send_keys(value)
                    print(f"✅ {label}: {value}")
                    return True
        except:
            continue
    return False

try:
    print("\n" + "=" * 70)
    print("Step 1: Opening RedBus Pune → Indore...")
    print("=" * 70)
    driver.get(url)
    print(f"✅ {driver.title}")
    time.sleep(3)
    screenshot("01_opened")

    print("\n" + "=" * 70)
    print("Step 2: Applying filters — AC + Sleeper...")
    print("=" * 70)
    time.sleep(2)
    for sel in [
        "//label[contains(., 'AC')]/input",
        "//label[contains(., 'Sleeper')]/input",
    ]:
        try:
            cbs = driver.find_elements(By.XPATH, sel)
            for cb in cbs:
                if cb.is_displayed() and not cb.is_selected():
                    driver.execute_script("arguments[0].click();", cb)
                    print("✅ Filter applied")
                    time.sleep(0.5)
        except:
            continue
    screenshot("02_filters")
    time.sleep(2)

    print("\n" + "=" * 70)
    print("Step 3: Sorting by Price (Low to High)...")
    print("=" * 70)
    for sel in ['select[class*="sort"]', 'select[name*="sort"]']:
        try:
            sort_el = driver.find_element(By.CSS_SELECTOR, sel)
            if sort_el.is_displayed():
                select = Select(sort_el)
                for opt in select.options:
                    t = opt.text.lower()
                    if 'price' in t and ('low' in t or 'asc' in t):
                        select.select_by_visible_text(opt.text)
                        print(f"✅ Sorted: {opt.text}")
                        time.sleep(2)
                        break
        except:
            continue
    screenshot("03_sorted")
    time.sleep(2)

    print("\n" + "=" * 70)
    print("Step 4: Clicking 'View Seats' on cheapest bus...")
    print("=" * 70)
    try:
        btns = driver.find_elements(By.XPATH, "//button[contains(., 'View Seats')]")
        for btn in btns[:3]:
            if btn.is_displayed() and btn.is_enabled():
                driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth'});", btn)
                time.sleep(1)
                btn.click()
                print("🚌 View Seats clicked on cheapest bus!")
                time.sleep(3)
                break
    except:
        pass
    screenshot("04_view_seats")

    print("\n" + "=" * 70)
    print("Step 5: Select a seat — you have 20 seconds...")
    print("=" * 70)
    print("\n!" * 35)
    print("!  Click a seat in the browser, then click Continue/Proceed  !")
    print("!" * 35)
    for i in range(20, 0, -1):
        print(f"⏳ {i}s remaining", end="\r")
        time.sleep(1)
    print("\n✅ Time's up!")

    print("\n" + "=" * 70)
    print("Step 6: Proceeding to details page...")
    print("=" * 70)
    for sel in ["//button[contains(., 'Proceed')]", "//button[contains(., 'Continue')]", "//button[contains(., 'Book')]"]:
        try:
            btns = driver.find_elements(By.XPATH, sel)
            for btn in btns:
                if btn.is_displayed() and btn.is_enabled():
                    print(f"✅ Clicking: {btn.text}")
                    btn.click()
                    time.sleep(3)
                    break
        except:
            continue
    screenshot("05_proceed")
    time.sleep(2)

    print("\n" + "=" * 70)
    print("Step 7: Filling passenger details...")
    print("=" * 70)
    print(f"👤 {PASSENGER['name']} | Age: {PASSENGER['age']} | {PASSENGER['gender']}")
    print(f"📧 {PASSENGER['email']}")
    print(f"📱 {PASSENGER['phone']}")
    time.sleep(2)

    fill('input[name*="name"], input[id*="name"], input[placeholder*="name"]', PASSENGER["name"], "Name")
    fill('input[name*="age"], input[id*="age"], input[placeholder*="age"]', PASSENGER["age"], "Age")

    try:
        gs = driver.find_elements(By.CSS_SELECTOR, 'select[name*="gender"], select[id*="gender"]')
        for g in gs:
            if g.is_displayed():
                Select(g).select_by_visible_text("Male")
                print("✅ Gender: Male")
                break
    except:
        pass

    fill('input[type="email"], input[name*="email"], input[id*="email"]', PASSENGER["email"], "Email")
    fill('input[type="tel"], input[name*="phone"], input[name*="mobile"], input[id*="phone"], input[id*="mobile"]', PASSENGER["phone"], "Phone")
    screenshot("06_details_filled")
    time.sleep(2)

    print("\n" + "=" * 70)
    print("Step 8: Proceeding to PAYMENT page...")
    print("=" * 70)
    for sel in ["//button[contains(., 'Pay')]", "//button[contains(., 'Continue')]", "//button[contains(., 'Proceed')]"]:
        try:
            btns = driver.find_elements(By.XPATH, sel)
            for btn in btns:
                if btn.is_displayed() and btn.is_enabled():
                    print(f"💳 Clicking: {btn.text}")
                    btn.click()
                    time.sleep(3)
                    break
        except:
            continue
    screenshot("07_payment")

    current_url = driver.current_url

    print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║                    ✅ AUTOMATION COMPLETED!                           ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                       ║
║  🚌 Pune → Indore  |  {DATE_STR}                                       ║
║                                                                       ║
║  ✅ Chrome opened VISIBLY                                            ║
║  ✅ RedBus loaded with AC + Sleeper filters                          ║
║  ✅ Sorted by price (low to high)                                    ║
║  ✅ View Seats clicked on cheapest                                    ║
║  ✅ Your details filled:                                              ║
║     • {PASSENGER['name']:<57} ║
║     • Age: {PASSENGER['age']}, Gender: {PASSENGER['gender']:<43} ║
║     • {PASSENGER['email']:<57} ║
║     • {PASSENGER['phone']:<57} ║
║                                                                       ║
╠══════════════════════════════════════════════════════════════════════╣
║                 💰 NOW COMPLETE PAYMENT IN BROWSER                    ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                       ║
║  1. The browser is STILL OPEN — look at it!                         ║
║  2. Select UPI as payment method                                     ║
║  3. Enter UPI ID: {PASSENGER['upi']:<39} ║
║  4. Click 'Pay Now'                                                   ║
║  5. Approve in your UPI app (GPay / PhonePe / Paytm)                ║
║                                                                       ║
║  🎉 HAPPY JOURNEY TO INDORE!                                         ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
""")

except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
    screenshot("ERROR")
    print("\n⚠️ Browser is still open. You can continue manually.")

print("\n📌 Browser stays open. Close Chrome manually when done.")
