@echo off
title DealwalaIndia - Bus Booking Automation
chcp 65001 >nul

:: ============================================================
::  DEALWALAINDIA - MASTER LAUNCHER (Windows)
::  One-click automation for RedBus booking
:: ============================================================

:MENU
cls
echo.
echo  ╔══════════════════════════════════════════════════════════════════╗
echo  ║                                                                 ║
echo  ║        🚀 DEALWALAINDIA BUS BOOKING AUTOMATION                  ║
echo  ║                                                                 ║
echo  ║        Passenger: Lalit Chordiya                                ║
echo  ║        UPI: lalitkchordiya-1@oksbi                             ║
echo  ║                                                                 ║
echo  ║        ONE-CLICK LAUNCHER                                       ║
echo  ║        Just pick a route and watch Chrome do the work!          ║
echo  ║                                                                 ║
echo  ╚══════════════════════════════════════════════════════════════════╝
echo.
echo  ============================================================
echo   SELECT ROUTE:
echo  ============================================================
echo.
echo     [1] Pune → Nashik
echo         (Tomorrow, shows ALL buses - cheapest first)
echo.
echo     [2] Pune → Indore
echo         (3 days ahead, AC + Sleeper, cheapest first)
echo.
echo     [3] Pune → Bangalore
echo         (3 days ahead, AC + Sleeper, cheapest first)
echo.
echo     [4] Run Environment Test (check setup)
echo.
echo     [5] Exit
echo.
echo  ============================================================
echo.

set /p choice="  Enter your choice (1-5) and press Enter: "

if "%choice%"=="1" goto ROUTE_NASHIK
if "%choice%"=="2" goto ROUTE_INDORE
if "%choice%"=="3" goto ROUTE_BANGALORE
if "%choice%"=="4" goto RUN_TEST
if "%choice%"=="5" goto EOF
goto INVALID

:ROUTE_NASHIK
cls
echo.
echo  ============================================================
echo   CHECKING SYSTEM...
echo  ============================================================
echo.
echo  [1/3] Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo  ERROR: Python not found!
    echo  Please install Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    goto MENU
)
echo  ✅ Python OK
echo.
echo  [2/3] Checking/Installing dependencies...
pip install --upgrade pip >nul 2>&1
pip install selenium webdriver-manager --upgrade
if errorlevel 1 (
    echo.
    echo  ⚠️  Dependency install had issues. Continuing anyway...
)
echo  ✅ Dependencies ready
echo.
echo  [3/3] Starting automation...
echo.
echo  ============================================================
echo   ROUTE: PUNE → NASHIK
echo   Chrome will OPEN VISIBLY in 5 seconds.
echo   DO NOT CLOSE THE BROWSER!
echo  ============================================================
echo.
timeout /t 5 /nobreak >nul
python scripts\book_pune_nashik.py
echo.
echo  ============================================================
echo   AUTOMATION COMPLETED - Check browser for payment
echo  ============================================================
echo.
pause
goto MENU

:ROUTE_INDORE
cls
echo.
echo  ============================================================
echo   CHECKING SYSTEM...
echo  ============================================================
echo.
echo  [1/3] Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo  ERROR: Python not found!
    echo  Please install Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    goto MENU
)
echo  ✅ Python OK
echo.
echo  [2/3] Checking/Installing dependencies...
pip install --upgrade pip >nul 2>&1
pip install selenium webdriver-manager --upgrade
if errorlevel 1 (
    echo.
    echo  ⚠️  Dependency install had issues. Continuing anyway...
)
echo  ✅ Dependencies ready
echo.
echo  [3/3] Starting automation...
echo.
echo  ============================================================
echo   ROUTE: PUNE → INDORE
echo   Chrome will OPEN VISIBLY in 5 seconds.
echo   DO NOT CLOSE THE BROWSER!
echo  ============================================================
echo.
timeout /t 5 /nobreak >nul
python scripts\book_pune_indore.py
echo.
echo  ============================================================
echo   AUTOMATION COMPLETED - Check browser for payment
echo  ============================================================
echo.
pause
goto MENU

:ROUTE_BANGALORE
cls
echo.
echo  ============================================================
echo   CHECKING SYSTEM...
echo  ============================================================
echo.
echo  [1/3] Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo  ERROR: Python not found!
    echo  Please install Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    goto MENU
)
echo  ✅ Python OK
echo.
echo  [2/3] Checking/Installing dependencies...
pip install --upgrade pip >nul 2>&1
pip install selenium webdriver-manager --upgrade
if errorlevel 1 (
    echo.
    echo  ⚠️  Dependency install had issues. Continuing anyway...
)
echo  ✅ Dependencies ready
echo.
echo  [3/3] Starting automation...
echo.
echo  ============================================================
echo   ROUTE: PUNE → BANGALORE
echo   Chrome will OPEN VISIBLY in 5 seconds.
echo   DO NOT CLOSE THE BROWSER!
echo  ============================================================
echo.
timeout /t 5 /nobreak >nul
python scripts\book_pune_bangalore.py
echo.
echo  ============================================================
echo   AUTOMATION COMPLETED - Check browser for payment
echo  ============================================================
echo.
pause
goto MENU

:RUN_TEST
cls
echo.
echo  ============================================================
echo   RUNNING ENVIRONMENT TEST...
echo  ============================================================
echo.
python test_setup.py
echo.
pause
goto MENU

:INVALID
cls
echo.
echo  ❌ Invalid choice! Please enter 1, 2, 3, 4, or 5.
echo.
pause
goto MENU

:EOF
cls
echo.
echo  Thank you for using DealwalaIndia Automation!
echo.
echo  Happy journey! 🚍
echo.
pause
